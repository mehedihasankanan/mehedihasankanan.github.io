import { initializeApp } from "https://www.gstatic.com/firebasejs/10.14.1/firebase-app.js";
import { getAuth, onAuthStateChanged, signInWithEmailAndPassword, signOut } from "https://www.gstatic.com/firebasejs/10.14.1/firebase-auth.js";
import { getFirestore, collection, addDoc, getDocs, getDoc, doc, setDoc, updateDoc, deleteDoc, query, where, orderBy, serverTimestamp } from "https://www.gstatic.com/firebasejs/10.14.1/firebase-firestore.js";
import { getStorage, ref, uploadBytes, getDownloadURL, deleteObject } from "https://www.gstatic.com/firebasejs/10.14.1/firebase-storage.js";
import { firebaseConfig } from "./firebase-config.js";

const configured = firebaseConfig?.apiKey && !String(firebaseConfig.apiKey).includes("PASTE_");
let app, auth, db, storage, currentUser = null;
let allPublicEntries = [], allAdminEntries = [], selectedFiles = [], profileFile = null;
const $ = id => document.getElementById(id);
const modal = $("adminModal");
$("year").textContent = new Date().getFullYear();

if (configured) {
  app = initializeApp(firebaseConfig);
  auth = getAuth(app); db = getFirestore(app); storage = getStorage(app);
  onAuthStateChanged(auth, user => {
    currentUser = user;
    if (user && !$("dashboardPanel").hidden) loadAdminEntries();
  });
  loadProfilePhoto();
} else {
  $("experienceCount").textContent = "Connect Firebase to activate the experience gallery";
}

$("menuToggle").addEventListener("click", () => {
  const open = $("mainNav").classList.toggle("open");
  $("menuToggle").setAttribute("aria-expanded", String(open));
});
document.querySelectorAll("#mainNav a").forEach(a => a.addEventListener("click", () => $("mainNav").classList.remove("open")));
$("openAdmin").addEventListener("click", () => {
  modal.hidden = false;
  if (!configured) $("authMessage").textContent = "Firebase is not configured yet. Follow SETUP.md to connect your project.";
  else if (currentUser) showDashboard();
  else showAuth();
});
$("closeAdmin").addEventListener("click", () => modal.hidden = true);
modal.addEventListener("click", e => { if (e.target === modal) modal.hidden = true; });
$("loginButton").addEventListener("click", async () => {
  if (!configured) return;
  $("authMessage").textContent = "Signing in…";
  try {
    await signInWithEmailAndPassword(auth, $("loginEmail").value.trim(), $("loginPassword").value);
    $("authMessage").textContent = ""; showDashboard();
  } catch (e) { $("authMessage").textContent = friendlyError(e); }
});
$("logoutButton").addEventListener("click", async () => { await signOut(auth); showAuth(); });
function showDashboard() { $("authPanel").hidden = true; $("dashboardPanel").hidden = false; loadAdminEntries(); loadAdminProfilePreview(); }
function showAuth() { $("authPanel").hidden = false; $("dashboardPanel").hidden = true; }
function friendlyError(e) {
  return ({"auth/invalid-credential":"Email or password is incorrect.","auth/too-many-requests":"Too many attempts. Please try again later.","auth/network-request-failed":"Network error. Check your connection."})[e.code] || e.message || "Something went wrong.";
}
function notify(message) { const t=$("toast"); t.textContent=message; t.classList.add("show"); setTimeout(()=>t.classList.remove("show"),2600); }
function escapeHtml(s="") { return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c])); }
const escapeAttr = escapeHtml;

async function loadProfilePhoto() {
  if (!configured) return;
  try {
    const snap = await getDoc(doc(db,"site","profile"));
    if (snap.exists() && snap.data().photoUrl) setProfilePhoto(snap.data().photoUrl);
  } catch (e) { console.warn("Profile photo unavailable",e); }
}
function setProfilePhoto(url) {
  const img=$("profilePhoto"), placeholder=$("profilePlaceholder");
  img.src=url; img.hidden=false; placeholder.hidden=true;
  const adminImg=$("adminProfilePreview"), adminPlaceholder=$("adminProfilePlaceholder");
  if (adminImg && adminPlaceholder) { adminImg.src=url; adminImg.hidden=false; adminPlaceholder.hidden=true; }
}
async function loadAdminProfilePreview() {
  try {
    const snap=await getDoc(doc(db,"site","profile"));
    if (snap.exists() && snap.data().photoUrl) {
      const img=$("adminProfilePreview"); img.src=snap.data().photoUrl; img.hidden=false; $("adminProfilePlaceholder").hidden=true;
    }
  } catch(e) { $("profileMessage").textContent="Unable to load current profile photo."; }
}
$("profilePhotoInput").addEventListener("change", e => {
  profileFile=e.target.files?.[0] || null;
  if (!profileFile) return;
  if (!profileFile.type.startsWith("image/")) { $("profileMessage").textContent="Please choose an image file."; profileFile=null; return; }
  if (profileFile.size > 8*1024*1024) { $("profileMessage").textContent="Image must be 8 MB or smaller."; profileFile=null; return; }
  const url=URL.createObjectURL(profileFile), img=$("adminProfilePreview");
  img.src=url; img.hidden=false; $("adminProfilePlaceholder").hidden=true;
  $("profileMessage").textContent="Preview ready. Select Save profile photo to publish it.";
});
$("saveProfilePhoto").addEventListener("click", async () => {
  if (!currentUser || !profileFile) { $("profileMessage").textContent="Sign in and choose a profile photo first."; return; }
  const btn=$("saveProfilePhoto"); btn.disabled=true; btn.textContent="Uploading…";
  try {
    const oldSnap=await getDoc(doc(db,"site","profile"));
    const old=oldSnap.exists()?oldSnap.data():{};
    const ext=(profileFile.name.split(".").pop()||"jpg").replace(/[^a-z0-9]/gi,"").toLowerCase()||"jpg";
    const path=`profile/${currentUser.uid}/portrait-${Date.now()}.${ext}`;
    const fileRef=ref(storage,path);
    await uploadBytes(fileRef,profileFile,{contentType:profileFile.type});
    const url=await getDownloadURL(fileRef);
    await setDoc(doc(db,"site","profile"),{photoUrl:url,photoPath:path,updatedAt:serverTimestamp(),ownerUid:currentUser.uid},{merge:true});
    setProfilePhoto(url); profileFile=null; $("profilePhotoInput").value=""; $("profileMessage").textContent="Profile photo updated.";
    if (old.photoPath) { try { await deleteObject(ref(storage,old.photoPath)); } catch(e) { console.warn("Old profile image cleanup skipped",e); } }
  } catch(e) { $("profileMessage").textContent=e.message||"Unable to upload profile photo."; }
  finally { btn.disabled=false; btn.textContent="Save profile photo"; }
});

async function loadPublicEntries() {
  if (!configured) return;
  try {
    const q=query(collection(db,"experiences"),where("visibility","==","public"),where("approved","==",true),orderBy("date","desc"));
    const snap=await getDocs(q); allPublicEntries=snap.docs.map(d=>({id:d.id,...d.data()})); renderPublicEntries();
  } catch(e) { $("experienceCount").textContent="Gallery is temporarily unavailable"; console.error(e); }
}
function renderPublicEntries(filter="All") {
  const list=filter==="All"?allPublicEntries:allPublicEntries.filter(x=>x.category===filter);
  $("experienceCount").textContent=`${allPublicEntries.length} approved ${allPublicEntries.length===1?"entry":"entries"} published`;
  const grid=$("experienceGrid");
  if (!list.length) { grid.innerHTML='<div class="empty-state"><div class="empty-icon">⌁</div><h3>No public entries yet.</h3><p>Approved engineering experiences will appear here when you publish them from your private workspace.</p></div>'; return; }
  grid.innerHTML=list.map(x=>`<article class="experience-card">
    ${x.photos?.[0]?.url?`<img src="${escapeAttr(x.photos[0].url)}" alt="${escapeAttr(x.title)}" loading="lazy" data-full="${escapeAttr(x.photos[0].url)}">`:""}
    <div class="experience-card-body"><div class="experience-meta"><span>${escapeHtml(x.category||"Other")}</span><span>${escapeHtml(x.date||"")}</span></div>
    <h3>${escapeHtml(x.title)}</h3><p>${escapeHtml(x.description||"")}</p>
    ${x.equipment?`<p class="experience-learning"><b>System:</b> ${escapeHtml(x.equipment)}</p>`:""}
    ${x.learning?`<p class="experience-learning"><b>Key learning:</b> ${escapeHtml(x.learning)}</p>`:""}
    </div></article>`).join("");
  grid.querySelectorAll("img[data-full]").forEach(img=>img.addEventListener("click",()=>openLightbox(img.dataset.full)));
}
$("filterRow").addEventListener("click",e=>{const b=e.target.closest("[data-filter]");if(!b)return;document.querySelectorAll(".filter").forEach(x=>x.classList.toggle("active",x===b));renderPublicEntries(b.dataset.filter);});
function openLightbox(url) { $("lightboxImage").src=url; $("lightbox").hidden=false; }
$("lightboxClose").addEventListener("click",()=>{$("lightbox").hidden=true;$("lightboxImage").src="";});
$("lightbox").addEventListener("click",e=>{if(e.target.id==="lightbox"){$("lightbox").hidden=true;$("lightboxImage").src="";}});

function collectExperienceFiles() {
  return [...($("entryCamera").files||[]),...($("entryGallery").files||[])].filter(f=>f.type.startsWith("image/"));
}
function renderPhotoPreview(existing=[]) {
  const wrap=$("photoPreview"); wrap.innerHTML="";
  existing.forEach(url=>{const img=document.createElement("img");img.alt="Selected or existing experience photo";img.src=url;wrap.append(img);});
  selectedFiles.forEach(file=>{const img=document.createElement("img");img.alt="Selected photo preview";img.src=URL.createObjectURL(file);wrap.append(img);});
}
function updateSelectedFiles() { selectedFiles=collectExperienceFiles(); renderPhotoPreview(); }
$("entryCamera").addEventListener("change",updateSelectedFiles);
$("entryGallery").addEventListener("change",updateSelectedFiles);
$("resetForm").addEventListener("click",resetForm);
function resetForm() {
  $("experienceForm").reset(); $("entryId").value=""; selectedFiles=[]; $("photoPreview").innerHTML="";
  $("entryDate").value=new Date().toISOString().slice(0,10); $("saveEntry").textContent="Save experience";
}
$("experienceForm").addEventListener("submit",async e=>{
  e.preventDefault(); if(!currentUser)return;
  selectedFiles=collectExperienceFiles();
  const visibility=$("entryVisibility").value, approved=$("entryApproved").checked;
  if(visibility==="public"&&!approved){$("saveMessage").textContent="To publish, confirm that public sharing has been approved.";return;}
  if(selectedFiles.length>8){$("saveMessage").textContent="Please upload no more than 8 photos per entry.";return;}
  const id=$("entryId").value, button=$("saveEntry"); button.disabled=true; button.textContent="Saving…";
  try {
    const data={title:$("entryTitle").value.trim(),category:$("entryCategory").value,date:$("entryDate").value,equipment:$("entryEquipment").value.trim(),description:$("entryDescription").value.trim(),learning:$("entryLearning").value.trim(),visibility,approved:visibility==="public"&&approved,updatedAt:serverTimestamp(),ownerUid:currentUser.uid};
    let entryId=id;
    if(id) await updateDoc(doc(db,"experiences",id),data);
    else { data.createdAt=serverTimestamp(); data.photos=[]; const created=await addDoc(collection(db,"experiences"),data); entryId=created.id; }
    if(selectedFiles.length){
      const photoRecords=[];
      for(const file of selectedFiles){
        if(file.size>8*1024*1024) throw new Error(`${file.name} is larger than 8 MB. Please resize it first.`);
        const safeName=file.name.replace(/[^a-zA-Z0-9._-]/g,"_");
        const path=`experience/${entryId}/${Date.now()}-${safeName}`;
        const fileRef=ref(storage,path); await uploadBytes(fileRef,file,{contentType:file.type});
        photoRecords.push({path,url:await getDownloadURL(fileRef),name:safeName});
      }
      const old=await getDoc(doc(db,"experiences",entryId)); const oldPhotos=old.exists()?(old.data().photos||[]):[];
      await updateDoc(doc(db,"experiences",entryId),{photos:[...oldPhotos,...photoRecords]});
    }
    $("saveMessage").textContent="Saved successfully."; resetForm(); await loadAdminEntries(); await loadPublicEntries();
  } catch(err) { $("saveMessage").textContent=err.message||"Unable to save this entry."; console.error(err); }
  finally { button.disabled=false; button.textContent="Save experience"; }
});
async function loadAdminEntries() {
  if(!currentUser)return;
  try {
    const snap=await getDocs(query(collection(db,"experiences"),where("ownerUid","==",currentUser.uid),orderBy("date","desc")));
    allAdminEntries=snap.docs.map(d=>({id:d.id,...d.data()})); renderAdminEntries();
  } catch(e) { $("adminEntries").textContent="Unable to load entries: "+e.message; }
}
function renderAdminEntries() {
  const el=$("adminEntries");
  if(!allAdminEntries.length){el.innerHTML='<p class="admin-note">No entries yet. Create your first experience above.</p>';return;}
  el.innerHTML=allAdminEntries.map(x=>`<div class="admin-entry"><div><strong>${escapeHtml(x.title)}</strong><small>${escapeHtml(x.date)} · ${escapeHtml(x.visibility)}${x.approved?" · approved":""}</small></div><div class="admin-entry-actions"><button data-edit="${escapeAttr(x.id)}">Edit</button><button data-delete="${escapeAttr(x.id)}">Delete</button></div></div>`).join("");
  el.querySelectorAll("[data-edit]").forEach(b=>b.addEventListener("click",()=>editEntry(b.dataset.edit)));
  el.querySelectorAll("[data-delete]").forEach(b=>b.addEventListener("click",()=>removeEntry(b.dataset.delete)));
}
function editEntry(id) {
  const x=allAdminEntries.find(e=>e.id===id); if(!x)return;
  $("entryId").value=x.id; $("entryTitle").value=x.title||""; $("entryCategory").value=x.category||"Other"; $("entryDate").value=x.date||"";
  $("entryEquipment").value=x.equipment||""; $("entryDescription").value=x.description||""; $("entryLearning").value=x.learning||"";
  $("entryVisibility").value=x.visibility||"private"; $("entryApproved").checked=!!x.approved;
  selectedFiles=[]; $("entryCamera").value=""; $("entryGallery").value=""; renderPhotoPreview((x.photos||[]).map(p=>p.url));
  $("saveEntry").textContent="Update experience"; $("saveMessage").textContent="Editing existing entry. Newly selected photos will be added.";
  $("experienceForm").scrollIntoView({behavior:"smooth",block:"start"});
}
async function removeEntry(id) {
  if(!confirm("Delete this experience entry and its uploaded photos?"))return;
  try {
    const x=allAdminEntries.find(e=>e.id===id);
    for(const p of (x?.photos||[])){try{await deleteObject(ref(storage,p.path));}catch(err){console.warn("Photo cleanup issue",err);}}
    await deleteDoc(doc(db,"experiences",id)); notify("Entry deleted."); await loadAdminEntries(); await loadPublicEntries();
  } catch(e) { notify("Delete failed: "+e.message); }
}
$("entryDate").value=new Date().toISOString().slice(0,10);
loadPublicEntries();
