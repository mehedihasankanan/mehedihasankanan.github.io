# Mehedi Hasan — Engineering Portfolio

A premium, responsive dark-theme portfolio with a professional profile-photo area, career timeline, education and projects, plus a Firebase-powered engineering experience journal.

## Project files

- `index.html` — complete portfolio and private admin interface
- `styles.css` — responsive dark premium design
- `app.js` — Firebase Authentication, Firestore and Storage logic
- `firebase-config.js` — Firebase web-app configuration placeholders
- `firestore.rules` — Firestore access policy
- `storage.rules` — Firebase Storage access policy
- `assets/favicon.svg` — site icon

## 1. Configure Firebase

1. Create a project at https://console.firebase.google.com/.
2. Add a Web App and copy its config into `firebase-config.js`.
3. In Authentication → Sign-in method, enable **Email/Password**.
4. In Authentication → Users, create your private administrator account.
5. Create a Firestore database.
6. Enable Firebase Storage. Check Firebase's current plan and billing requirements before enabling Storage.

The Firebase web-app config is intended to be visible in a browser. Never put service-account keys, private server credentials or passwords in this repository.

## 2. Apply security rules

1. Copy your administrator account's **UID** from Authentication → Users.
2. Replace `REPLACE_WITH_ADMIN_UID` in both `firestore.rules` and `storage.rules` with that exact UID.
3. Publish the Firestore rules in Firestore → Rules.
4. Publish the Storage rules in Storage → Rules.
5. Do not use open rules such as `allow read, write: if true`.

The profile portrait is intentionally public. Profile-photo writes and all experience management are restricted to the administrator. Experience photos are readable publicly only when the entry is marked public and approved.

## 3. Add Firebase web configuration

Open `firebase-config.js` and replace each `PASTE_...` value with the corresponding Firebase Web App configuration value. Do not paste a service-account JSON file here.

## 4. Publish with GitHub Pages

1. Upload all project files and the `assets` folder to the root of `mehedihasankanan.github.io`.
2. Commit and push to the `main` branch.
3. In GitHub repository → Settings → Pages, select **Deploy from a branch**, branch `main`, folder `/ (root)`.
4. Wait for deployment and visit `https://mehedihasankanan.github.io`.

Use the HTTPS GitHub Pages URL when testing uploads. Browser camera/file-picker behavior depends on the device and browser.

## 5. Upload your professional profile photo

1. Open the live portfolio and choose **Admin sign in**.
2. Sign in with the Firebase administrator account.
3. Under **Public Profile Photo**, select a clear professional headshot and choose **Save profile photo**.
4. The image will appear in the portfolio hero section. Until then, the site displays the MH placeholder.

Recommended image: front-facing, good lighting, simple background, head and shoulders visible. Use your own photo; do not use a generated or misleading identity image.

## 6. Add engineering experience photos

1. In the private admin workspace, create an experience entry.
2. Use **Take photo** to open the camera (where supported) or **Choose from gallery** to select existing images. You can use both sources for one entry.
3. Add a title, category, date, equipment/system, description and key learning.
4. Save as **Private** by default. Only select **Public** after the required written permission has been obtained and tick the approval confirmation.
5. The public journal displays only approved public entries. You can edit or delete your entries from the same admin workspace.

Limits in this starter: maximum 8 photos per entry, maximum 8 MB per image. Each profile image is also limited to 8 MB.

## 7. Privacy and hospital safety

- Do not upload patient photos, patient names/records, medical screens, staff/visitor faces, access cards, passwords, security layouts, restricted technical-room details or confidential hospital documents.
- Do not publish any UHSL/hospital photo without the required written authorization.
- Keep sensitive learning notes and unapproved photographs private.
- The approval checkbox is a workflow reminder, not a substitute for written authorization.

## 8. Personal details to verify before launch

The public contact section uses the email, LinkedIn and GitHub links currently associated with the portfolio. Verify these links before publishing. Add a current, updated CV only after confirming that its job title and employment dates are accurate.

## 9. Troubleshooting

- If the experience list reports a missing Firestore index, open the Firebase error link and create the suggested composite index.
- If sign-in fails, confirm Email/Password authentication is enabled and the admin user exists.
- If uploads fail, check the Storage bucket, published Storage rules, administrator UID and Firebase billing/plan requirements.
- The camera option may not appear on every phone/browser. The Gallery picker remains available.
