# Mehedi Hasan — Engineering Portfolio

Premium responsive portfolio website with a Firebase-backed private engineering journal.

## Quick start

1. Read `SETUP.md` from top to bottom.
2. Add your Firebase Web App settings to `firebase-config.js`.
3. Create your Firebase Email/Password admin user.
4. Replace `REPLACE_WITH_ADMIN_UID` in both rules files and publish the rules.
5. Upload the project files to the root of `mehedihasankanan.github.io` and enable GitHub Pages on `main` / root.
6. Open the live HTTPS site, sign in through **Admin sign in**, and upload your professional profile photo.

## Included features

- Premium responsive dark theme
- Professional profile-photo slot and private admin upload
- Career timeline, education, projects and technical expertise
- Engineering journal with category filters
- Camera and gallery upload for experience photos
- Private-by-default experience entries and approval-gated public publishing
- Firebase Authentication, Firestore and Storage security rules

See `SETUP.md` for Firebase configuration and privacy requirements.
